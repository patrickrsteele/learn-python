a = [1, 3, 5, 7, 9]
n = 0
while n < len(a):
    print(a[n] ** 2)
    n = n + 1
print("Program exiting")
