def greeting():
    return "Hello!"

print("Today's greeting is:")
print(greeting())
