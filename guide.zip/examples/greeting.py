def greeting():
    print("Hello!")

print("Today's greeting is:")
greeting()
