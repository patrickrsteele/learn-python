number = input("Please enter a number: ")
if number > 0:
    print("You entered a positive number")
else:
    print("You entered a non-positive number")
print("Exiting program")
