a = [1, 3, 5, 7, 9]
for v in a:
    print(v ** 2)
print("Program exiting")
